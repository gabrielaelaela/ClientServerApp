package utilities.exceptions;

public class WrongCommandNameException extends RuntimeException {
    public WrongCommandNameException(String s) {super(s);}
}
