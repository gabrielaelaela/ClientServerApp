package utilities.exceptions;

public class RecursiveException extends RuntimeException {
    public RecursiveException(String input) {
        super(input);
    }
}
