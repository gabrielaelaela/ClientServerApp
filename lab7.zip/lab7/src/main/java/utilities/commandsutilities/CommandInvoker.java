package utilities.commandsutilities;

import utilities.history.History;
import utilities.usercommands.UserCommand;
import utilities.users.User;

public class CommandInvoker {

    public static String invoke(UserCommand userCommand, User user) {
        try {
            History.getInstance().addCommandToHistory(userCommand);
            return userCommand.execute(user);
        } catch (Exception e) {
            System.out.println("-----------!!!!!!!!!!!!!!!!!!!!!!!!-----------");
            if (e.getMessage() == null) System.out.println(e.getCause().getMessage());
            else System.out.println(e.getMessage());
            System.out.println("-----------!!!!!!!!!!!!!!!!!!!!!!!!-----------");
            System.out.println();
        }
        return null;
    }
}
