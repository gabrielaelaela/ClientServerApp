package utilities.usercommands;

public interface ClientServerCommand extends UserCommand {
}
