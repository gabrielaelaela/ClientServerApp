package utilities.usercommands;

public interface ServerCommand extends UserCommand {
}
