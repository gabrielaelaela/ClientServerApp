package utilities.usercommands;

public interface ClientCommand extends UserCommand {
}
