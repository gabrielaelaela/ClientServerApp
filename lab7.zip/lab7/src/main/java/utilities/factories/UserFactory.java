package utilities.factories;

public class UserFactory {
    private String username;
    private String password;

    public UserFactory(String username, String password) {
        setUsername(username);
        setPassword(password);
    }

    public void setUsername(String username) {

    }

    public void setPassword(String password) {

    }
}
