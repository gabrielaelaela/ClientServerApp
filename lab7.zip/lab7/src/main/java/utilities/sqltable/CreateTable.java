package utilities.sqltable;

import java.sql.*;
import java.time.ZonedDateTime;

public class CreateTable {

    public static void main(String[] args) throws SQLException, ClassNotFoundException {
        Connection c = null;
        PreparedStatement preparedStatement;
        String createSQL;

        Class.forName("org.postgresql.Driver");
        c = DriverManager.getConnection("jdbc:postgresql://pg/studs", "s337038", "slg369");

        createSQL = "create table Organizations\n" +
                "(\n" +
                "id                 SERIAL PRIMARY KEY, \n" +
                "name               varchar(255),\n" +
                "x                  float(53),\n" +
                "y                  float(24),\n" +
                "creation_date      TIMESTAMP WITH TIME ZONE,\n" +
                "annualTurnover     INT,\n" +
                "type               varchar(255), \n" +
                "zipcode            varchar(255), \n" +
                "username           varchar(255));";


        preparedStatement = c.prepareStatement(createSQL);
        preparedStatement.executeUpdate();


        createSQL = "Create Table Users(login varchar primary key, password varchar)";
        preparedStatement = c.prepareStatement(createSQL);
        preparedStatement.executeUpdate();
    }
}
