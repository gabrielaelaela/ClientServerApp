package utilities.sql;

import utilities.factories.OrganizationFactory;
import utilities.iowork.ConsolePrint;
import utilities.organizations.Organization;
import utilities.upgradedcollections.UpgradedPriorityQueue;

import java.sql.*;
import java.util.ArrayList;

public class SQLCollection {

    private static Connection connection;
    private static ConsolePrint consolePrint = new ConsolePrint();

    public static void setup() {
        String jdbcURL = "jdbc:postgresql://localhost:5432/lab7";
        try {
            connection = DriverManager.getConnection(jdbcURL, "postgres", "2390");
            consolePrint.println("Connected to PostgreSQL server");
        } catch (SQLException e) {
            consolePrint.println("Error connecting to PostgreSQL server");
            e.printStackTrace();
        }
    }

    public static boolean checkPassword(String username, String password) throws SQLException {
        String sql = "SELECT * FROM users";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
        while (resultSet.next()) {
            String user = resultSet.getString("username");
            if (user.equals(username)) {
                String pass = resultSet.getString("password");
                if (pass.equals(password)) return true;
                else return false;
            }
        }
        return false;
    }

    public static boolean containsUser(String username) throws SQLException {
        String sql = "SELECT * FROM users";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next()) {
            String user = resultSet.getString("username");
            if (user.equals(username)) return true;
        }

        return false;
    }

    public static void addUser(String username, String password) throws SQLException {
        String sql = "INSERT INTO users (username, password) VALUES (?, ?)";
        PreparedStatement preparedStatement = connection.prepareStatement(sql);
        preparedStatement.setString(1, username);
        preparedStatement.setString(2, password);
        preparedStatement.executeUpdate();
    }

    public static UpgradedPriorityQueue<Organization> getCollection() throws SQLException {
        UpgradedPriorityQueue upgradedPriorityQueue = new UpgradedPriorityQueue();

        String sql = "SELECT * FROM organization";

        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next()) {
            upgradedPriorityQueue.add(OrganizationFactory.buildFromDatabase(resultSet));
        }

        return upgradedPriorityQueue;
    }

    public static void addToCollection(Organization organization) throws SQLException {
        String sql = "INSERT INTO organization (name, x, y, creationDate, annualTurnover, type, zipcode, user) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(sql);

        statement.setString(1, organization.getName());
        statement.setFloat(2, organization.getCoordinates().getX());
        statement.setDouble(3, organization.getCoordinates().getY());
        statement.setDate(4, Date.valueOf(organization.getCreationDate()));
        statement.setLong(5, organization.getAnnualTurnover());
        statement.setString(6, organization.getType());
        statement.setString(7, organization.getPostalAddress().getZipCode());
        statement.setString(8, organization.getUsername());

        statement.executeUpdate();
    }

    public static void clearCollection() throws SQLException {
        String sql = "DELETE FROM organization";
        Statement statement = connection.createStatement();
        statement.executeQuery(sql);
    }

    public static void clearUsersCollection(String username) throws SQLException {
        String sql = "DELETE FROM organization WHERE name = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, username);
    }

    public static ArrayList<Long> getAnnualTurnovers() throws SQLException {
        ArrayList<Long> listOfAnnualTurnovers = new ArrayList<>();

        String sql = "SELECT * FROM organization";

        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);

        while (resultSet.next()) {
            listOfAnnualTurnovers.add(resultSet.getLong("annualTurnover"));
        }

        return listOfAnnualTurnovers;
    }

    public static int getNumberOfElements() throws SQLException {
        String sql = "SELECT COUNT(*) FROM organization";
        PreparedStatement statement = connection.prepareStatement(sql);
        ResultSet resultSet = statement.executeQuery();
        resultSet.next();
        return resultSet.getInt(1);
    }

    public static void removeById(int id) throws SQLException {
        String sql = "DELETE FROM TABLE WHERE ID = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, id);
    }

    public static String getUsername(int id) throws SQLException {
        String sql = "SELECT * FROM organization WHERE ID = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, id);
        ResultSet resultSet = statement.executeQuery();
        resultSet.next();
        return resultSet.getString(2);
    }

    public static void changeObject(Organization organization) throws SQLException {
        String sql = "UPDATE organization SET (name, x, y, creationDate, annualTurnover, type, zipcode, user) = (?, ?, ?, ?, ?, ?, ?, ?)  WHERE id = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, organization.getName());
        statement.setFloat(2, organization.getCoordinates().getX());
        statement.setDouble(3, organization.getCoordinates().getY());
        statement.setDate(4, Date.valueOf(organization.getCreationDate()));
        statement.setLong(5, organization.getAnnualTurnover());
        statement.setString(6, organization.getType());
        statement.setString(7, organization.getPostalAddress().getZipCode());
        statement.setString(8, organization.getUsername());
        statement.setInt(9, organization.getId());
        statement.executeQuery();
    }
}
