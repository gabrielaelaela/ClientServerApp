package utilities.idobjects;

public interface IdObject {
    int getId();
    void setId(int id);
}
